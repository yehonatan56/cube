<?php

/**
 * @package Just a simple plugin
 * @version 1.0.0
 */
/*
Plugin Name: cube
Plugin URI:
Description: This is just a simple plugin
Author: Daniel Kalaora
Version: 1.0.0
Author URI: https://chidoripunk.github.io/
*/


// We need some CSS to position the paragraph.
function custom_animation_css($args)
{
	 $width = !empty($args["width"]) ? $args["width"] : 200; // check if empty then value is set to 200 otherwise uses the value given
	 $name = !empty($args["name"]) ? $args["name"] : "first";
	 $aniamtionSpeed = !empty($args["animation_speed"]) ? $args["animation_speed"] : "20s";
	 $aniamtionRotateX = !empty($args["animation_rotatex"]) ? $args["animation_rotatex"] : 0;
	 $aniamtionRotateY = !empty($args["animation_rotatey"]) ? $args["animation_rotatey"] : 0;
	 $aniamtionRotateZ = !empty($args["animation_rotatez"]) ? $args["animation_rotatez"] : 0;
	 $cubeBackgroundColor = !empty($args["cube_background_color"]) ? $args["cube_background_color"] : "#000";
	 $cubeFrameColor = !empty($args["cube_frame_color"]) ? $args["cube_frame_color"] : "#000";
	 $cubeBorderSize = !empty($args["cube_border_size"]) ? $args["cube_border_size"] : 0;
	 $cubeBorderColor = !empty($args["cube_border_color"]) ? $args["cube_border_color"] : "#fff";
	 $cubeFaceTopImageUrl = !empty($args["cube_face_top_image_url"]) ? $args["cube_face_top_image_url"] : "";
	 $cubeFaceRightImageUrl = !empty($args["cube_face_right_image_url"]) ? $args["cube_face_right_image_url"] : "";
	 $cubeFaceBottomImageUrl = !empty($args["cube_face_bottom_image_url"]) ? $args["cube_face_bottom_image_url"] : "";
	 $cubeFaceLeftImageUrl = !empty($args["cube_face_left_image_url"]) ? $args["cube_face_left_image_url"] : "";
	 $cubeFaceBackImageUrl = !empty($args["cube_face_back_image_url"]) ? $args["cube_face_back_image_url"] : "";
	 $cubeFaceFrontImageUrl = !empty($args["cube_face_front_image_url"]) ? $args["cube_face_front_image_url"] : "";

	 $animationTransform = "";
	 if ($aniamtionRotateX != 0) {
		 $animationTransform .= "rotateX(" . $aniamtionRotateX . "deg)";
	 }
	 if ($aniamtionRotateY != 0) {
		 $animationTransform .= "rotateY(" . $aniamtionRotateY . "deg)";
	 }
	 if ($aniamtionRotateZ != 0) {
		 $animationTransform .= "rotateZ(" . $aniamtionRotateZ . "deg)";
	 }

	 $debugStyle = "";

	 if (!empty($args["debug_mode"]) && $args["debug_mode"]) {
		$debugStyle = ".wireframe { position: relative; }\r\n.wireframe:after { content: 'wireframe'; color: #000; position: absolute; left: 15px; }\r\n.wireframe:checked ~ .cube > .cube-face { background: none; border: 3px solid " . $cubeFrameColor . "; }\r\n";
	}

	 $html = "<style type=\"text/css\" id=\"cube-animations-style-block\">\r\n";
	 $html .= "@keyframes rotate { to { transform: " . $animationTransform . "; } }\r\n";
	 $html .= "." . $name ."{ position: relative; width: " . $width . "px; height: " . $width . "px; transform-style: preserve-3d; animation: rotate " . $aniamtionSpeed . "s infinite linear; }\r\n";
	 $html .= "." . $name ." .cube-face { position: absolute; width: " . $width . "px; height: " . $width . "px; background-color: " . $cubeBackgroundColor . "; background-size: contain; background-repeat: no-repeat; background-position: center; border: " . $cubeBorderSize . "px solid " . $cubeBorderColor . "; }\r\n";
	 $html .= "." . $name ." .top { background-image: url(\"" . $cubeFaceTopImageUrl . "\"); transform: rotateX(90deg) translateZ(" . ($width / 2) . "px); }\r\n";
	 $html .= "." . $name ." .right { background-image: url(\"" . $cubeFaceRightImageUrl . "\"); transform: translateZ(-" . ($width / 2) . "px) translateY(2px) rotateY(180deg); }\r\n";
	 $html .= "." . $name ." .bottom { background-image: url(\"" . $cubeFaceBottomImageUrl . "\"); transform: rotateX(90deg) translateZ(-" . ($width / 2) . "px) ; }\r\n";
	 $html .= "." . $name ." .left { background-image: url(\"" . $cubeFaceLeftImageUrl . "\"); transform: translateZ(" . ($width / 2) . "px) translateY(-2px); }\r\n";
	 $html .= "." . $name ." .back { background-image: url(\"" . $cubeFaceBackImageUrl . "\"); transform: rotateY(90deg) translateZ(" . ($width / 2) . "px);  }\r\n";
	 $html .= "." . $name ." .front { background-image: url(\"" . $cubeFaceFrontImageUrl . "\"); transform:  rotateY(90deg)translateZ(-" . ($width / 2) . "px) rotateY(180deg) ; }\r\n";
	 $html .= $debugStyle;
	 $html .= "</style>";
	 echo $html;
}


function custom_animation($atts)
{
	add_action('wp_head', custom_animation_css( $atts )); // fire the action of the style tag

	$debugFrame = ""; // empty string if debug mode is false

	if (!empty($args["debug_mode"]) && $args["debug_mode"]) {
		$debugFrame = "<input type=\"checkbox\" class=\"wireframe\">";
	}
	//var_dump($atts);

	// from here on it's the HTML structure
	$html = $debugFrame;
	$html .= "<div class=" . $atts["name"] .">";
	$html .= 	"<div class=\"cube-face top\"></div>";
	$html .= 	"<div class=\"cube-face right\"></div>";
	$html .= 	"<div class=\"cube-face left\"></div> ";
	$html .= 	"<div class=\"cube-face bottom\"></div>";
	$html .= 	"<div class=\"cube-face front\"></div>";
	$html .= 	"<div class=\"cube-face back\"></div>";
	$html .= "</div>";
	echo $html;
}


add_shortcode("show-custom-animation", "custom_animation"); // fire the plugin into action